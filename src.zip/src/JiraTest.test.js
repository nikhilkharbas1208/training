// TableRedux.test.js
// jest.mock('axios');
import React from 'react';
import { render, screen } from '@testing-library/react';
import TableRedux from './components/TableRedux';
import { Provider } from 'react-redux';
import { MemoryRouter } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import { JiraIssueContext } from './App';
import i18n from 'i18next';
import { I18nextProvider } from 'react-i18next';

const mockStore = configureStore([]);
const store = mockStore({
  issues: {
    items: [],
    loading: false,
    error: null,
  },
});

// Basic mock translation
i18n.init({
  lng: 'en',
  resources: {
    en: {
      translation: {
        jiraTicket: 'Jira Ticket',
        create: 'Create',
        edit: 'Edit',
        save: 'Save',
        cancel: 'Cancel',
        delete: 'Delete',
        ticketid: 'Ticket ID',
        type: 'Type',
        title: 'Title',
        summary: 'Summary',
        status: 'Status',
        assignee: 'Assignee',
        created: 'Created',
        priority: 'Priority',
      },
    },
  },
});

test('renders the Jira Ticket heading', () => {
  render(
    <Provider store={store}>
      <MemoryRouter>
        <JiraIssueContext.Provider value={{ projectKey: 'TEST' }}>
          <I18nextProvider i18n={i18n}>
            <TableRedux />
          </I18nextProvider>
        </JiraIssueContext.Provider>
      </MemoryRouter>
    </Provider>
  );

  expect(screen.getByText(/Jira Ticket/i)).toBeInTheDocument();
});
