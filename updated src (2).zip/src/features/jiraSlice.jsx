

import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  issues: [],
  loading: false,
  editedRows: {},
};

const jiraSlice = createSlice({
  name: 'jira',
  initialState,
  reducers: {
    setIssues: (state, action) => {
      state.issues = action.payload;
    },
    setLoading: (state, action) => {
      state.loading = action.payload;
    },
    setEditedRows: (state, action) => {
      state.editedRows = action.payload;
    },
    updateIssueInRow: (state, action) => {
      const { rowId, updatedData } = action.payload;
      state.editedRows[rowId] = updatedData;
    },
    deleteIssueById: (state, action) => {
      const idToDelete = action.payload;
      state.issues = state.issues.filter((i) => i.id !== idToDelete);
      delete state.editedRows[idToDelete];
    },
    
  },
});

export const {
  setIssues,
  setLoading,
  setEditedRows,
  updateIssueInRow,
  deleteIssueById,
} = jiraSlice.actions;

export default jiraSlice.reducer;
