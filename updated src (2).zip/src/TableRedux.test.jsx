jest.mock('./API/JiraAxios', () => {
  return {
    default: {
      interceptors: {
        request: {
          use: jest.fn(),
        },
      },
      get: jest.fn(() => Promise.resolve({ data: {} })),
      post: jest.fn(),
      put: jest.fn(),
      delete: jest.fn(),
    },
  };
});

jest.mock('react-router-dom', () => {
  const original = jest.requireActual('react-router-dom');
  return {
    ...original,
    NavLink: ({ children, to }) => <a href={to}>{children}</a>,
    useNavigate: () => jest.fn(),
  };
});

jest.mock('react-error-boundary', () => ({
  ErrorBoundary: ({ children }) => children,
}));


import { render, screen } from '@testing-library/react';
import TableRedux from './components/TableRedux';
import { JiraIssuesProvider } from './context/JiraIssuesContext';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import { store } from './store/store';
import { JiraIssueContext } from './App';
import { configureStore } from '@reduxjs/toolkit';
import issuesReducer from './features/jiraIssueSlice';


// Wrap component with all providers
const MockWrapper = ({ children }) => (
  <Provider store={store}>
    <JiraIssueContext.Provider value={{ projectKey: 'TEST123' }}>
      <JiraIssuesProvider projectKey="TEST123">
        <BrowserRouter>{children}</BrowserRouter>
      </JiraIssuesProvider>
    </JiraIssueContext.Provider>
  </Provider>
);

describe('TableRedux Component', () => {
  it('renders Jira Ticket header', async () => {
    render(<TableRedux />, { wrapper: MockWrapper });
    expect(await screen.findByText(/jira ticket/i)).toBeInTheDocument();
  });

  it('shows Create and Edit buttons', async () => {
    render(<TableRedux />, { wrapper: MockWrapper });
    expect(await screen.findByText(/create/i)).toBeInTheDocument();
    expect(await screen.findByText(/edit/i)).toBeInTheDocument();
  });
});
const contextValue = { projectKey: 'DEMO123' };

// Mock issues to load into Redux store
const mockIssues = [
  {
    id: '10001',
    key: 'JIRA-1',
    summary: 'Fix login issue',
    title: 'Login Bug',
    status: 'To Do',
    priority: 'High',
    type: 'Bug',
    assignee: 'Alice',
    created: '2024-06-01',
    description: 'Login fails with 401',
  },
  {
    id: '10002',
    key: 'JIRA-2',
    summary: 'Improve dashboard UI',
    title: 'Dashboard UI',
    status: 'In Progress',
    priority: 'Medium',
    type: 'Task',
    assignee: 'Bob',
    created: '2024-06-02',
    description: 'Redesign dashboard layout',
  },
];

// Custom wrapper with test store
const renderWithProviders = (ui, { preloadedState } = {}) => {
  const store = configureStore({
    reducer: {
      issues: issuesReducer,
    },
    preloadedState: {
      issues: {
        items: mockIssues,
        loading: false,
        error: null,
        ...preloadedState,
      },
    },
  });

  return render(
    <Provider store={store}>
      <JiraIssueContext.Provider value={contextValue}>
        <JiraIssuesProvider projectKey="DEMO123">
          <BrowserRouter>{ui}</BrowserRouter>
        </JiraIssuesProvider>
      </JiraIssueContext.Provider>
    </Provider>
  );
};

describe('TableRedux - Table Rendering', () => {
  it('renders issue rows from redux store', async () => {
    renderWithProviders(<TableRedux />, { wrapper: MockWrapper });

    expect(await screen.findByText(/jira ticket/i)).toBeInTheDocument();
    expect(await screen.findByText(/Fix login issue/i)).toBeInTheDocument();
    // expect(await screen.findByText(/Create/i)).toBeInTheDocument();
    //     expect(await screen.findByText(/edit/i)).toBeInTheDocument();
    expect(await screen.getByText(/Login Bug/i)).toBeInTheDocument();
    // expect(screen.getByText(/Improve dashboard UI/i)).toBeInTheDocument();
    // expect(screen.getByText(/Dashboard UI/i)).toBeInTheDocument();
  });
});
